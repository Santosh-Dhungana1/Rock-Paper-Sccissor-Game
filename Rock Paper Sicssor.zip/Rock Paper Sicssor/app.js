userScore=0;
comScore=0;

const chioces=document.querySelectorAll(".choice");
const msg=document.querySelector("#msg")
const userScorePara=document.querySelector("#k")
const comScorePara=document.querySelector("#l")
const genComputerChoice= () =>
{
    //rock ,paper, scissor
    const options=["rock","paper","sicssor"];
   const randomNum=Math.floor(  Math.random() * 3);
   return options[randomNum];

   

}
const playGame=(userChoice) =>
{
    console.log("User Choice:", userChoice);
   
const comChoice=genComputerChoice();
console.log("Computer Choice:",comChoice);
const drawGame =() =>{
    console.log("iT WAS DRAW")
    msg.innerHTML="Draw game,Play again";
    document.getElementById("msg").style.backgroundColor="orange";
   }
   const showWinner= (usrWin, userChoice,comChoice) =>
   {
    if(usrWin){
        userScore++;
        console.log("You Win")
        userScorePara.innerHTML=userScore;
        msg.innerHTML=`You win..Your ${userChoice} beats  ${comChoice}`;
        document.getElementById("msg").style.backgroundColor="green";
    }
    else{
        comScore++;
        comScorePara.innerHTML=comScore;
        console.log("You lose")
        msg.innerHTML=`You lost..computer's ${comChoice} beats  ${userChoice}`;
        document.getElementById("msg").style.backgroundColor="red";
    }
   }
if(userChoice === comChoice){
    drawGame();
    }
    else{
        let usrWin=true;
        if(userChoice==="rock"){
            usrWin= comChoice==="paper" ? false:true;
        }
        else if (userChoice==="paper") {
            comChoice= comChoice === "scissor" ? false:true;
        } else {
            comChoice === "rock" ? false:true;
        }
        showWinner(usrWin,userChoice,comChoice);
    }
}



chioces.forEach(choice => {
    // console.log(choice)
    choice.addEventListener("click", () =>{
        const userChoice=choice.getAttribute("id");
        playGame(userChoice)
        // console.log(choiceId," was clicked");
        // console.log(genComputerChoice,"Play")

    }
    )
    
});

